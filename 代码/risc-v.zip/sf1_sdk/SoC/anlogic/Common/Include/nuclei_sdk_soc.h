// See LICENSE for license details.
#ifndef _NUCLEI_SDK_SOC_H
#define _NUCLEI_SDK_SOC_H

#ifdef __cplusplus
 extern "C" {
#endif

#include "nuclei.h"
#include "nuclei_libopt.h"


#ifdef __cplusplus
}
#endif
#endif

