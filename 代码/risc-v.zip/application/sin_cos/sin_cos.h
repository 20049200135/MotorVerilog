/*
 * sin_cos.h
 *
 *  Created on: 2024年11月5日
 *      Author: DaZhouGe668
 */

#ifndef APPLICATION_SIN_COS_SIN_COS_H_
#define APPLICATION_SIN_COS_SIN_COS_H_

#include "nuclei.h"
#include "math.h"

#define TABLE_SIZE 512 // 查找表的大小
#define PI 3.14159265358
#define ANGLE_STEP (2 * PI / TABLE_SIZE)

void init_sine_table() ;
float get_sine(float angle) ;
float get_cosine(float angle) ;

#endif /* APPLICATION_SIN_COS_SIN_COS_H_ */
