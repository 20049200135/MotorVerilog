/*
 * sin_cos.c
 *
 *  Created on: 2024年11月5日
 *      Author: DaZhouGe668
 */

#include "sin_cos.h"

float sine_table[TABLE_SIZE];

void init_sine_table() {
    for (int i = 0; i < TABLE_SIZE; i++) {
        sine_table[i] = sin( i * 0.012271f );
    }
}

float get_sine(float angle) {
    int index = (int)( angle * 81.487331f ) % TABLE_SIZE ;
    if (index < 0) index += TABLE_SIZE ;  // 处理负角度
    return sine_table[index] ;
}

float get_cosine(float angle) {
    return get_sine(angle + 1.5708 ) ;  // 余弦是正弦的90°相位
}
