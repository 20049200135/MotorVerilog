/*
 * Encode.c
 *
 *  Created on: 2024年10月27日
 *      Author: Dong
 */

#include "Encoder.h"
TypeDef_Encode Encode;

void Encoder_Start(TypeDef_AHB_Encoder * ahb_encoder,int mask){
	if(ahb_encoder == NULL){
		return;
	}
	ahb_encoder->encode_control_reg |= mask;
}

void Encoder_Stop(TypeDef_AHB_Encoder * ahb_encoder,int mask){
	if(ahb_encoder == NULL){
		return;
	}
	ahb_encoder->encode_control_reg &= mask;
}

void Encoder_Init(TypeDef_Encode *encoder){

	encoder->Cpr = 2500*4;
}

float Encoder_GetRawCount(TypeDef_AHB_Encoder * ahb_encoder,TypeDef_Encode *encoder){
	if( ahb_encoder && encoder  == NULL ){
		return 0.0;
	}
	float angle;

	if(ahb_encoder->dir_reg){
		encoder->DIR = 1;
	}else{
		encoder->DIR = -1;
	}
	angle = ((ahb_encoder->cnt_reg) / (float)encoder->Cpr) *360;
	return angle;
}

void Encoder_Update(TypeDef_Encode *encoder){
	  float angle_data = Encoder_GetRawCount(ENCODER,encoder);

	  float d_angle = angle_data - encoder->AngleDataPrev;
	  // if overflow happened track it as full rotation
	  if(fabs(d_angle) > (0.8*encoder->Cpr) ) encoder->FullRotationOffset += d_angle > 0 ? -_2PI : _2PI;

	  // (number of full rotations)*2PI + current sensor angle
	  encoder->CurrentAngle = encoder->DIR * (encoder->FullRotationOffset + ( angle_data / (float)encoder->Cpr) * _2PI);
	  encoder->AngleDataPrev = angle_data;


	  // calculate sample time
	  unsigned long now_us = SysTimer_GetLoadValue();
	  float Ts = (now_us - encoder->VelocityCalcTimestamp)*1.0/25000000.0;
	  // quick fix for strange cases (micros overflow)
	  if(Ts <= 0 || Ts > 0.5) Ts = 1e-4;

	  // velocity calculation
	  float vel = (encoder->CurrentAngle - encoder->AnglePrev)/Ts;

	  encoder->AnglePrev = encoder->CurrentAngle;
	  encoder->VelocityCalcTimestamp = now_us;
	  encoder->CurrentVelocity = vel;
}

/*******************************************************************************/
int	INT_ElecTheta ;
float	F_ElecTheta ;
void Encoder_MACRO ( TypeDef_AHB_Encoder *ahb_encoder , Encoder *encoder )
{
	if( ahb_encoder && encoder  == NULL )
	{
			return  ;
	}
	//记录方向
	//记录当前加了偏移量的计数值
	encoder->RawTheta = ahb_encoder->cnt_reg + encoder->CalibratedAngle ;
	if ( encoder->RawTheta < 0 )
		encoder->RawTheta = encoder->RawTheta + encoder->CntMax ;
	else if ( encoder->RawTheta > encoder->CntMax )
		encoder->RawTheta = encoder->RawTheta - encoder->CntMax ;

	//转换为机械角度
	encoder->MechTheta =  encoder->MechScaler  * encoder->RawTheta ;
	//转换为电角度,并将其范围固定在[0 , 2PI]中
	encoder->ElecTheta = encoder->PolePairs*encoder->MechTheta ;
	INT_ElecTheta  = ( 1000000.0f * encoder->ElecTheta ) ; //扩大六位
	F_ElecTheta  = INT_ElecTheta % 6283185 ;
	encoder->ElecTheta = F_ElecTheta * 0.000001f ;
}


/** get current angle (rad) */
float Encoder_GetAngle(TypeDef_Encode *encoder){

	  return encoder->CurrentAngle;
};
/** get current angular velocity (rad/s) **/
float Encoder_GetVelocity(TypeDef_Encode *encoder){

	return encoder->CurrentVelocity;
};

