/*
 * Encode.h
 *
 *  Created on: 2024年10月27日
 *      Author: Dong
 */

#ifndef ICODE_SAMPLEFOC_ENCODE_H_
#define ICODE_SAMPLEFOC_ENCODE_H_
#include "nuclei.h"
#include "math.h"

#ifndef _2PI
#define _2PI 6.28318
#endif
#ifndef _PI
#define _PI  3.14159
#endif

#define AHB_ENCODE_BASE_ADDR				(0x40020000UL)
#define AHB_ENCODE_CONTROL_REG		AHB_ENCODE_BASE_ADDR + 0x00
#define AHB_DIR_REG											AHB_ENCODE_BASE_ADDR + 0x04
#define AHB_CNT_REG										AHB_ENCODE_BASE_ADDR + 0x08

#define ENCODER_STRAT									(0x00000001UL)
#define ENCODER_STOP									(0x00000000UL)


typedef struct{
	uint32_t encode_control_reg;
	uint32_t dir_reg;
	int32_t cnt_reg;
}TypeDef_AHB_Encoder;

#define ENCODER							((TypeDef_AHB_Encoder *)AHB_ENCODE_BASE_ADDR)

typedef enum {
    CW = -1,
    CCW = 1
}TypeDef_DIR;

typedef struct{
    float Cpr; //!< Maximum range of the sensor

    // total angle tracking variables
    float FullRotationOffset; //!<number of full rotations made
    float AngleDataPrev; //!< angle in previous position calculation step

    // velocity calculation variables
    float AnglePrev; //!< angle in previous velocity calculation step
    long VelocityCalcTimestamp; //!< last velocity calculation timestamp

    float CurrentAngle, CurrentVelocity;

    TypeDef_DIR DIR;
}TypeDef_Encode;



void Encoder_Init(TypeDef_Encode *encoder);
void Encoder_Start(TypeDef_AHB_Encoder * ahb_encoder,int mask);
void Encoder_Stop(TypeDef_AHB_Encoder * ahb_encoder,int mask);

float Encoder_GetRawCount(TypeDef_AHB_Encoder * ahb_encoder,TypeDef_Encode *encoder);
void Encoder_Update(TypeDef_Encode *encoder);
/** get current angle (rad) */
float Encoder_GetAngle(TypeDef_Encode *encoder);
/** get current angular velocity (rad/s) **/
float Encoder_GetVelocity(TypeDef_Encode *encoder);


/*****************************************************************************************/
typedef struct {
				float 			ElecTheta;        		// Output: Motor Electrical angle (Q24)
				float 			MechTheta;     		// Output: Motor Mechanical Angle (Q24)
				uint16_t		Direction;    			// Output: Motor rotation direction (Q0)
				uint16_t 		CntMax ;      		 	// 计数最大值
				int32_t 		RawTheta;       	 	// Variable: Raw angle from EQEP Postiion counter (Q0)
				float 			MechScaler;      	// 将编码器脉冲数转换为角度值 Parameter: 0.9999/total count (Q30)
				uint16_t 		LineEncoder;    	 // Parameter: Number of line encoder (Q0)
				uint16_t 		PolePairs;       		// Parameter: Number of pole pairs (Q0)
				int32_t 		CalibratedAngle; // Parameter: Raw angular offset between encoder index and phase a (Q0)
} Encoder ;

#define	Encoder_DEFAULT 	 {	0,\
															0,\
															0,\
															10000 ,\
															0 ,\
															(  2*M_PI*0.25/2500 ) ,\
															2500 ,\
															4 ,\
															165 ,\
}

void Encoder_MACRO ( TypeDef_AHB_Encoder *ahb_encoder , Encoder *encoder ) ;

#endif /* ICODE_SAMPLEFOC_ENCODE_H_ */
