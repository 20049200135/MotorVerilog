/*
 * speed_fir.h
 *
 *  Created on: 2024年11月1日
 *      Author: DaZhouGe668
 */

#ifndef SPEED_FIR_H_
#define FIR_SPEED_FIR_H_
#include "math.h"
#include "stdio.h"

typedef	struct {
		float			ElecTheta ;
		uint32_t		Direction ;
		float			OldElecTheta ;
		float			Speed ;
		float			BaseRpm ;			//转速转换比例系数，将角速度转换为转速
		float			K1 ;						//角度转换比例系数，通过编码器脉冲数计算角度
		float			K2 ;						//K2,K3 滤波系数
		float			K3 ;
		float			SpeedRpm ;
		float			Tmp ;
}	SPEED_MEAS_Encoder ;

void	 SPEED_FR_MACRO( SPEED_MEAS_Encoder *v ) ;

#endif /* APPLICATION_SPEED_FIR_SPEED_FIR_H_ */
