/*
 * speed_fir.c
 *
 *  Created on: 2024年11月1日
 *      Author: DaZhouGe668
 */

#include "speed_fir.h"

void	 SPEED_FR_MACRO( SPEED_MEAS_Encoder *v )
{
	/* Differentiator*/
	if (  ( v->ElecTheta > 0.0724f ) && ( v->ElecTheta < 6.210768f )  )			//当转速为3750时，超出0.05ms旋转0.025PI电角度的范围
		v->Tmp = v->K1*( v->ElecTheta - v->OldElecTheta) ;
	else
		v->Tmp = v->Speed ;
/* Low-pass filter*/
	v->Tmp = v->K2*v->Speed + v->K3*v->Tmp ;
/* Saturate the output */
	if( v->Tmp > 1256 )			//电角速度
		v->Tmp = 1256 ;
	else if ( v->Tmp < -1256 )
		v->Tmp = -1256 ;

	v->Speed = v->Tmp ;
/* Update the electrical angle */
	v->OldElecTheta = v->ElecTheta ;
/* Change motor speed from pu value to rpm value (GLOBAL_Q -> Q0)转换为转速*/
	v->SpeedRpm = v->BaseRpm*v->Speed ;
}
