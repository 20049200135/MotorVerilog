#include <stdio.h>

#include "../../../../SoC/anlogic/Board/sf1_eval/Include/nuclei_sdk_hal.h"
#include "nuclei.h"
#include "./Clark_Park/Clark_Park.h"
#include "./MPCC/MPCC.h"
#include "./PI/PI.h"
//#include "./ADRC/ADRC.h"
#include "./speed_fir/speed_fir.h"
#include "./Encoder/Encoder.h"
#include "./adc/ad7606.h"
#include "./pwm/pwm.h"
#include "./SVPWM/SVPWM.h"
#include "./sin_cos/sin_cos.h"
#include "float.h"
#include "dsi_configure.h"

int				flag_key1 = 0 ;
int				flag_start = 0 ;
int				cntTheta_start = 0 ;
int				FOC_SpeedCnt = 1 ;
int 				lsr = 0 ;		//状态切换计数  由调零状态切换至主函数程序
int				FOC_Speed = 100 ;
#define		Offset_RawTheta			165

//中断周期
#define		Period_Max			12500
#define		Period_Max_2 		6250
#define 		ISR_FREQUENCY 	8
float			T = 0.001 / ISR_FREQUENCY ; // 单位 KHz		5Khz

void fpga0_handler(void) ;	//声明主中断函数

//定义ABC->DQ坐标系变换结构体
ClarkPark_struct		I_ClarkPark = ClarkPark_DEFAULT , *i_clarkpark = &I_ClarkPark ;
//DQ->ALFA_BETA坐标系变换结构体
Park_struct 				U_InvPark = { 0 , 0 , 0 , 0 , 0 } , *u_invpark = &U_InvPark ;

//定义SVPWM算法结构体
SVPWM_struct		SVPWM = { 0 , 0 , 0 , 0 ,0 ,0 ,0 } , *svpwm = &SVPWM ;

//定义Double_MPCC电流环控制结构体
MPCC_struct			MPCC1 = MPCC_DEFAULTS  ,	*mpcc1 = &MPCC1 ;

////定义ADRC自抗扰控制结构体
//ADRC_controller		ADRC_controller1 ,	 *adrc_controller1 = &ADRC_controller1 ;
//ADRC_state				ADRC_state1 = ADRC_Initstate;

//定义ADC采集结构体
extern		TypeDef_Adc 		Ad7606;

//定义Encoder编码器采集数据结构体
Encoder									Encoder1 = Encoder_DEFAULT , *encoder1 = &Encoder1 ;
extern 	TypeDef_Encode Encode ;
//定义SPEED_FIR速度滤波模块结构体
SPEED_MEAS_Encoder	Speed_fir	,	*speed_fir = &Speed_fir ;

//定义PI控制器结构体
PI_CONTROLLER				PI_SPEED = { 0 , 0 , 0 , 0 , 0 , 5 , -5 , 0 , 0 , 0 , 0 , 0 }, *pi_speed = &PI_SPEED ;
PI_CONTROLLER				PI_Id = { 0 , 0 , 0 , 0 , 0 , 217 , -217 , 0 , 0 , 0 , 0 , 0 } , 	*pi_id = &PI_Id ;
PI_CONTROLLER				PI_Iq = { 0 , 0 , 0 , 0 , 0 , 217 , -217 , 0 , 0 , 0 , 0 , 0 } , 	*pi_iq = &PI_Iq ;

//引用定义的正余弦计算查找表
extern float sine_table[TABLE_SIZE];

float	I_As , I_Bs , I_Cs , U_Ds , U_Qs , main_ThetaE ;

//定义三相电流和电压采集量
//float		I_As , I_Bs , I_Cs , Udc;
//int			Sin1 , Sin2 , Sin3 , Cos1 , Cos2 , Cos3 ;
int main(void)
{
	//PWM_FPGA初始化
	pwm_cmd( 0 , DISABLE) ;
	set_pwm_clkdiv(0 , 0) ;
	set_pwm_period( 0 , Period_Max ) ; 	// 100Mhz -> 0.0001s , 对应的载波最大值为5000
	Encoder_Init(&Encode);
	//ADC_FPGA初始化
	/***NULL***/

	//Encoder_FPGA初始化
	/***NULL***/
	//屏幕初始化
	dsi_0_configure();
	//ADC结构体初始化
	/***NULL***/
	printf("dsi0 configure done!!\n");
	//Encoder编码器结构体初始化
	Encoder1.LineEncoder = 2500 ; 		Encoder1.PolePairs = 4 ;
	Encoder1.CntMax = 10000 ;
	Encoder1.MechScaler = 	0.00062831f ; 			//( *2*M_PI /Encoder1.CntMax )由编码器计数值转换为角度
	Encoder1.CalibratedAngle = Offset_RawTheta ;

	//MPCC模型预测双矢量电流控制结构体
	/***NULL***/

	//PI控制器结构体初始化
	PI_SPEED.Kp = 0.1 ; 		PI_SPEED.Ki = 0.01 ;

	PI_Id.Kp = 0.01 ; 				PI_Id.Ki = 0.001 ;
	PI_Iq.Kp = 0.05 ;				PI_Iq.Ki = 0.01 ;
//	//P比例位置环参数初始化
//	P_POSITION.Kp = 5.5  ;

	//Speed_fir速度滤波器初始化
	Speed_fir.K1 = 1.0f /T ;						Speed_fir.K2 = 1.0f /(1 + T*2*_PI*5) ;					//周期频率为5k
	Speed_fir.K3 = 1.0f -  Speed_fir.K2 ; Speed_fir.BaseRpm = 2.3873 ;

	//是能GPIO 初始化按键模块
	gpio_enable_input( GPIO , 1<<0 );
	gpio_enable_input(GPIO , 1<<1);

	//计算sin_LUT查找表
	init_sine_table() ;

	//进行三相电流初始化偏移采集
	ad7606_offset( &Ad7606 , 3000 ) ;

	//使能PWM输出
	pwm_cmd( 0 , ENABLE ) ;

	//中断使能并配置中断函数和优先级
    __enable_irq();
	ECLIC_Register_IRQ( FPGA0_IRQn, ECLIC_NON_VECTOR_INTERRUPT,ECLIC_POSTIVE_EDGE_TRIGGER, 1, 1,fpga0_handler );
	int flag_increase = 1;
	while(1)
    {
//		printf ( "%f \r\n " , Speed_fir.SpeedRpm) ;
    	if ( !gpio_read( GPIO , 1<<0 ) )
    	{
    		flag_key1 = 1  ;
    	}

    	if ( !gpio_read( GPIO , 1 << 1) )
    	{
    		if(flag_increase){
        		if ( FOC_Speed < 1000)
        		{
        			FOC_Speed += 100 ;
        		}
        		else
        		{
        			FOC_Speed = 1000;
        			flag_increase = 0 ;
        		}
    		}else{
        		if ( FOC_Speed >100)
        		{
        			FOC_Speed -= 100 ;
        		}
        		else
        		{
        			FOC_Speed = 100;
        			flag_increase = 1;
        		}
    		}
    		for( int i = 0 ; i<5000000 ; i++ ) ;
    	}
   	}
}

void fpga0_handler(void)
{
//	gpio_write(GPIO , 1<<1 ,  1) ;
	//采集电机三相电流和总电压
	ad7606_Update( &Ad7606 , 0 ) ;
	I_As = Ad7606.Value.iu ;
	I_Bs = Ad7606.Value.iv ;
	I_Cs = Ad7606.Value.iw ;
//	float	Udc = Ad7606.Value.Udc ;
//通过编码器计数值获得角度和速度
	if ( flag_key1 == 0 )
	{
		//等待启动按钮,避免开始接电时出现两路都为高电平的情况
	}
	else
	{
		//调零部分
		if ( lsr  < 1200 )
		{
			SVPWM.Ualfa = 25 ; SVPWM.Ubeta = 0 ;
			SVPWM_MACRO( svpwm ) ;
			set_pwm_duty( 0 , SVPWM.Sa_CCP  );
			//通道B
			set_pwm_duty( 1 , SVPWM.Sb_CCP );
			//通道C
			set_pwm_duty( 2 , SVPWM.Sc_CCP );
			lsr ++ ;
		}
		else if ( lsr >= 1200 && lsr <3000 )
		{
			set_pwm_duty( 0 , Period_Max/0.5f  );
			//通道B
			set_pwm_duty( 1 , Period_Max/0.5f );
			//通道C
			set_pwm_duty( 2 , Period_Max*0.5f );
			cntTheta_start = ENCODER->cnt_reg ;
			lsr ++ ;
		}

		//控制主函数,双闭环控制
		else if ( lsr >= 3000 )
		{
		/**************用来计算电角度偏差*****************/
			//启动阶段
			if ( flag_start == 0 )
			{
				if ( ( ENCODER->cnt_reg ) <= 10000  )
				{
					flag_start = 1 ;
				}
				else
				{
					main_ThetaE = ( ENCODER->cnt_reg - cntTheta_start + 30 ) * 0.00251327f ;
					//Encoder1.MechTheta = ( ENCODER->cnt_reg - cntTheta_start + 50 )*0.00062831f ;
					Speed_fir.ElecTheta =  main_ThetaE ;
					SPEED_FR_MACRO( speed_fir ) ;
				}
			}
			//根据计数值和偏移量来计算电角度
			else
			{
				Encoder_MACRO( ENCODER , encoder1 ) ;
				main_ThetaE = Encoder1.ElecTheta ;
				Speed_fir.ElecTheta = Encoder1.ElecTheta ;
				SPEED_FR_MACRO( speed_fir ) ;
			}
			/************双闭环控制算法**************/
			if ( FOC_SpeedCnt == 10 )
			{
				//位置闭环控制算法
				PI_SPEED.Ref = FOC_Speed	 ; PI_SPEED.Fbk = Speed_fir.SpeedRpm ; //机械角度
				PI_MACRO( pi_speed ) ;
				FOC_SpeedCnt = 1 ;
			}
			else
			{
				FOC_SpeedCnt ++ ;
			}
	/******************************* ClarkPark *********************************/
			int		INT_CPThetaE = (int)( main_ThetaE*81.487331f ) + TABLE_SIZE  ;

			int Sin1 =  INT_CPThetaE % TABLE_SIZE ;
			int Cos1 =  ( INT_CPThetaE + 128 ) % TABLE_SIZE ;

			int Sin2 = ( INT_CPThetaE - 171 ) % TABLE_SIZE ;
			int Cos2 = ( INT_CPThetaE - 43 ) % TABLE_SIZE ;

			int Sin3 = (  INT_CPThetaE + 171 ) % TABLE_SIZE ;
			int Cos3 = ( INT_CPThetaE + 299 ) % TABLE_SIZE ;

			float I_Ds = 0.666667f * ( I_As*sine_table[Cos1] + I_Bs*sine_table[Cos2] + I_Cs *sine_table[Cos3] );
			float I_Qs = 0.666667f * ( -I_As*sine_table[Sin1] - I_Bs*sine_table[Sin2] - I_Cs*sine_table[Sin3]  ) ;

			PI_Id.Ref = 0.0 ; 						PI_Id.Fbk = I_Ds ;
			//接受上面转速环计算得到的结果------PI控制
			PI_Iq.Ref = PI_SPEED.Out ;  PI_Iq.Fbk = I_Qs ;
			PI_MACRO( pi_id ) ; 				 PI_MACRO( pi_iq ) ;
			U_Ds = PI_Id.Out ; 	 				U_Qs = PI_Iq.Out ;

/**********************************invPark变换*********************************/
			int	IP_INT_ThetaE = (int)(main_ThetaE*81.487331f) + TABLE_SIZE ;
			int 	IP_Sin1 = IP_INT_ThetaE  % TABLE_SIZE ;
			int 	IP_Cos1 =  ( IP_INT_ThetaE + 128 ) % TABLE_SIZE ;

			float IP_Alfa = U_Ds * sine_table[ IP_Cos1 ]  - U_Qs * sine_table[ IP_Sin1 ] ;
			float IP_Beta = U_Ds * sine_table[ IP_Sin1 ] + U_Qs * sine_table[ IP_Cos1 ] ;

			SVPWM.Ualfa = IP_Alfa ; SVPWM.Ubeta = IP_Beta ;
			SVPWM_MACRO( svpwm ) ;
			set_pwm_duty( 0 , SVPWM.Sa_CCP );
			//通道B
			set_pwm_duty( 1 , SVPWM.Sb_CCP );
			//通道C
			set_pwm_duty( 2 , SVPWM.Sc_CCP );
//			gpio_write(GPIO , 1<<1 ,  0) ;
		}
	}
}


//    	SVPWM.Ualfa = 150.335 ; SVPWM.Ubeta = 15.632541 ;
//		SVPWM_MACRO( svpwm ) ;
//		/***************CLARKPARK_TEST******************/
//		I_ClarkPark.As = 0.21563 ; I_ClarkPark.Bs = 0.001235 ; I_ClarkPark.Cs = 0.11153 ;
//		float	CP_ThetaE = 0.01111 ;
//		int		INT_ThetaE = (int)( CP_ThetaE*81.487331f ) + TABLE_SIZE  ;
//
//		int Sin1 =   INT_ThetaE % TABLE_SIZE ;
//		int Cos1 =  ( INT_ThetaE + 128 ) % TABLE_SIZE ;
//
//		int Sin2 = ( INT_ThetaE - 171 ) % TABLE_SIZE ;
//		int Cos2 = ( INT_ThetaE - 43 ) % TABLE_SIZE ;
//
//		int Sin3 = (  INT_ThetaE + 171 ) % TABLE_SIZE ;
//		int Cos3 = ( INT_ThetaE + 299 ) % TABLE_SIZE ;
//
//		float CP_Ds = 0.666667f * ( I_ClarkPark.As*sine_table[Cos1] + I_ClarkPark.Bs*sine_table[Cos2] + I_ClarkPark.Cs *sine_table[Cos3] );
//		float CP_Qs = 0.666667f * ( -I_ClarkPark.As*sine_table[Sin1] - I_ClarkPark.Bs*sine_table[Sin2] - I_ClarkPark.Cs*sine_table[Sin3]  ) ;
//
//		/**********************InvPARK*******************/
//		float	IP_ThetaE = 6.02253 ;
//		float	IP_Ds = 3.45682 , IP_Qs = 20.3351 ;
//
//		int	IP_INT_ThetaE = (int)(IP_ThetaE*81.487331f) + TABLE_SIZE ;
//		int 	IP_Sin1 = IP_INT_ThetaE  % TABLE_SIZE ;
//		int 	IP_Cos1 =  ( IP_INT_ThetaE + 128 ) % TABLE_SIZE ;
//
//		float IP_Alfa = IP_Ds * sine_table[ IP_Cos1 ]  - IP_Qs * sine_table[ IP_Sin1 ] ;
//		float IP_Beta = IP_Ds * sine_table[ IP_Sin1 ] + IP_Qs * sine_table[ IP_Cos1 ] ;
//    	printf( "D = %f  Q = %f \n  Alfa = %f  Beta = %f \n " , CP_Ds , CP_Qs , IP_Alfa , IP_Beta   ) ;

