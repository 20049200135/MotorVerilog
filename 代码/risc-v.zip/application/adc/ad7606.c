/*
 * ad7606.c
 *
 *  Created on: 2024年10月9日
 *      Author: Dong
 */

#include "ad7606.h"
TypeDef_Adc Ad7606;

Data_TpyeDef * get_ad7606_data(AD7606_Typedef * ad7606,Data_TpyeDef * data){

	if(ad7606 == NULL){

		return NULL;
	}
	data->data_reg1 = ad7606->data_reg1;
	data->data_reg2 = ad7606->data_reg2;
	data->data_reg3 = ad7606->data_reg3;
//	data->data_reg4 = ad7606->data_reg4;
	return data;
}

States_TypeDef * get_ad7606_states(AD7606_Typedef * ad7606,States_TypeDef * states){
	if(ad7606 == NULL){
		return NULL;
	}
	if(ad7606->states_reg){
		states = valid ;
	}else{
		states = idle ;
	}
	return states;
}

void Calculate_Real_Voltage(Data_TpyeDef *data,Voltage_TpyeDef * voltage){

	if(data == NULL){
		return;
	}
	voltage->iu =  data->data_reg1 * 0.00091699f ;			//	0.00015263f * 6.0096f
	voltage->iv =  data->data_reg2 * 0.00091699f ;
	voltage->iw =  data->data_reg3 *0.00091699f ;
//	voltage->Udc =  data->data_reg4 *0.01895852f ;     // * 124.2123f
}
void ad7606_start(AD7606_Typedef * ad7606,int mask){
	if(ad7606 == NULL){
		return;
	}
	ad7606->control_reg |= mask;

}
void ad7606_stop(AD7606_Typedef * ad7606,int mask){
	if(ad7606 == NULL){
		return;
	}
	ad7606->control_reg &= mask;
}

void ad7606_offset(TypeDef_Adc* adc,int cnt){
	float  iu = 0.0, iv = 0.0, iw = 0.0;

	ad7606_start(AD7606,AD7606_START_MASK);

	for(int i = 0;i<cnt;i++){
		get_ad7606_data(AD7606,&(adc->AD7606_Data));
		Calculate_Real_Voltage(&(adc->AD7606_Data),&(adc->offsetValue));
		iu += adc->offsetValue.iu;
		iv += adc->offsetValue.iv;
		iw += adc->offsetValue.iw;
	}
	adc->offsetValue.iu = iu / cnt;
	adc->offsetValue.iv = iv / cnt;
	adc->offsetValue.iw = iw / cnt;

}
//_sector取0时不运算
void ad7606_Update(TypeDef_Adc* adc,int _sector){
	float iu = 0, iv = 0, iw = 0;

	get_ad7606_data(AD7606,&(adc->AD7606_Data));
	Calculate_Real_Voltage(&(adc->AD7606_Data),&(adc->Value));

	adc->Value.iu = adc->Value.iu - adc->offsetValue.iu;
	adc->Value.iv = adc->Value.iv - adc->offsetValue.iv;
	adc->Value.iw = adc->Value.iw - adc->offsetValue.iw;

}
//	if(_sector == 1 || _sector == 6)
//		adc->Value.iu = -adc->Value.iv - adc->Value.iw;
//	else if(_sector == 2 || _sector == 3)
//		adc->Value.iv = -adc->Value.iu - adc->Value.iw;
//	else if(_sector == 4 || _sector == 5)
//		adc->Value.iw = -adc->Value.iu - adc->Value.iv;
	//	if(adc->Value.iu > 3.0) adc->Value.iu = 3.0;
	//	if(adc->Value.iv > 3.0) adc->Value.iv = 3.0;
	//	if(adc->Value.iw > 3.0) adc->Value.iw = 3.0;
