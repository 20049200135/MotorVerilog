/*
 * ad7606.h
 *
 *  Created on: 2024年10月9日
 *      Author: Dong
 */

#ifndef AD7606_H_
#define AD7606_H_

#include "nuclei.h"
#include "stdio.h"

#define AHB_AD7606_BASE_ADDR			( 0x40010000UL )
#define AHB_CONTROL_REG					AHB_AD7606_BASE_ADDR + 0x00
#define AHB_DATA1_REG							AHB_AD7606_BASE_ADDR + 0x04
#define AHB_DATA2_REG							AHB_AD7606_BASE_ADDR + 0x08
#define AHB_DATA3_REG							AHB_AD7606_BASE_ADDR + 0x0C
#define AHB_DATA4_REG							AHB_AD7606_BASE_ADDR + 0x10
#define AHB_DATA5_REG							AHB_AD7606_BASE_ADDR + 0x14
#define AHB_DATA6_REG							AHB_AD7606_BASE_ADDR + 0x18
#define AHB_DATA7_REG							AHB_AD7606_BASE_ADDR + 0x1C
#define AHB_DATA8_REG							AHB_AD7606_BASE_ADDR + 0x20
#define AHB_STATES_REG							AHB_AD7606_BASE_ADDR + 0x24


//#define uint32_t						unsigned int
//#define uint16_t						unsigned short int
//#define uint8_t							unsigned char
//#define int32_t						 	int
//#define int16_t							short int
//#define int8_t							char
typedef struct{
	uint32_t control_reg;
	int32_t data_reg1;
	int32_t data_reg2;
	int32_t data_reg3;
	int32_t data_reg4;
	uint32_t states_reg;
}AD7606_Typedef ;

#define 				AD7606					( (AD7606_Typedef *)AHB_AD7606_BASE_ADDR )

typedef struct{
	int32_t data_reg1;
	int32_t data_reg2;
	int32_t data_reg3;
	int32_t data_reg4;
}Data_TpyeDef;

typedef struct{
	float iu;
	float iv;
	float iw;
	float Udc;
}Voltage_TpyeDef;
typedef enum{
	idle = 0,
	valid
}States_TypeDef;

#define AD7606_START_MASK			(0x00000001UL)
#define AD7606_STOP_MASK			(0x00000000UL)


//States_TypeDef AD7606_States;
//Data_TpyeDef  AD7606_Data;
//Voltage_TpyeDef Value,offsetValue;

typedef struct{
	States_TypeDef AD7606_States;
	Data_TpyeDef  AD7606_Data;
	Voltage_TpyeDef Value,offsetValue;
}TypeDef_Adc;


void ad7606_offset(TypeDef_Adc* adc,int cnt);
void ad7606_Update(TypeDef_Adc* adc,int _sector);

void ad7606_start(AD7606_Typedef * ad7606,int mask);
void ad7606_stop(AD7606_Typedef * ad7606,int mask);
Data_TpyeDef * get_ad7606_data(AD7606_Typedef * ad7606,Data_TpyeDef * data);
States_TypeDef * get_ad7606_states(AD7606_Typedef * ad7606,States_TypeDef * states);

void Calculate_Real_Voltage(Data_TpyeDef *data,Voltage_TpyeDef * voltage);

#endif /* ICODE_AD7606_AD7606_H_ */
