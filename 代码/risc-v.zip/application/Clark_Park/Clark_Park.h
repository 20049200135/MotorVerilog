/*
 * Clark_Park.h
 *
 *  Created on: 2024年11月1日
 *      Author: DaZhouGe668
 */

#ifndef CLARK_PARK_H_
#define CLARK_PARK_H_

#include "math.h"
#include "./sin_cos/sin_cos.h"
//引用定义的正余弦计算查找表


typedef	struct {
	float	As ;
	float	Bs ;
	float	Cs ;
	float	ThetaE ;
	float	Ds ;
	float	Qs ;
} ClarkPark_struct ;

typedef	struct {
	float	Ds ;
	float	Qs ;
	float	ThetaE ;
	float	Alfa ;
	float	Beta ;
} Park_struct ;
#define ClarkPark_DEFAULT 	{ 	0,\
															0 ,\
															0 ,\
															0 ,\
															0 ,\
															0 ,\
										}

void ClarkPark_Trans( ClarkPark_struct *v ) ;
void invPark_Trans ( Park_struct *v ) ;

#endif /* APPLICATION_CLARK_PARK_CLARK_PARK_H_ */
