/*
 * Clark_Park.c
 *
 *  Created on: 2024年11月1日
 *      Author: DaZhouGe668
 */

#include "Clark_Park.h"
extern float sine_table[TABLE_SIZE];


void ClarkPark_Trans( ClarkPark_struct *v )
{
    int Sin1 = (int)( v->ThetaE * 81.487331f ) % TABLE_SIZE ;
    	if ( Sin1 < 0) Sin1 += TABLE_SIZE ;
    int Cos1 =  (int)( ( v->ThetaE + 1.5708 )* 81.487331f ) % TABLE_SIZE ;
    	if ( Cos1 < 0) Cos1 += TABLE_SIZE ;

	int Sin2 = (int)( ( v->ThetaE - 2.094395f ) * 81.487331f ) % TABLE_SIZE ;
       if ( Sin2 < 0) Sin2 += TABLE_SIZE ;
	int Cos2 = (int)( ( v->ThetaE - 0.523595f  ) * 81.487331f ) % TABLE_SIZE ;
		if ( Cos2 < 0) Cos2 += TABLE_SIZE ;

	int Sin3 = (int)( ( v->ThetaE + 2.094395f ) * 81.487331f ) % TABLE_SIZE ;
		if ( Sin3 < 0) Sin3 += TABLE_SIZE ;
	int Cos3 = (int)( ( v->ThetaE + 3.6651913f ) * 81.487331f ) % TABLE_SIZE ;
		if ( Cos3 < 0) Cos3 += TABLE_SIZE ;

	v->Ds = 0.6666667f * ( v->As*sine_table[Sin1] + v->Bs*sine_table[Sin2] + v->Cs *sine_table[Sin3] );
	v->Qs = 0.6666667f * ( v->As*sine_table[Cos1] + v->Bs*sine_table[Cos2] + v->Cs*sine_table[Cos3] ) ;
}

void invPark_Trans ( Park_struct *v )
{
	float	sin_ThetaE = get_sine( v->ThetaE ) ;
	float	cos_ThetaE = get_cosine( v->ThetaE ) ;
	v->Alfa = v->Ds * cos_ThetaE  - v->Qs * sin_ThetaE ;
	v->Beta = v->Ds * sin_ThetaE + v->Qs * cos_ThetaE ;
}
