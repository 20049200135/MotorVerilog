/*
 * Parameter.h
 *
 *  Created on: 2024年11月1日
 *      Author: DaZhouGe668
 */

#ifndef PARAMETER_H_
#define PARAMETER_H_

#define		Rs		0.605
#define		Ls		0.002317		//
#define		Phif		0.0727847		// 等于  30*sqrt(2)/PI/p*Ke / 1000    , Ke = 37.14
#define		Pn		4

#define		J			0.001544
#define		Kt		( 1.5*Pn*Phif )

#define 	ISR_FREQUENCY 	8
#define	Ts  								( 0.001 / ISR_FREQUENCY)  // 单位 KHz		15Khz

#endif /* PARAMETER_H_ */
