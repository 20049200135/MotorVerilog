/*
 * PI.c
 *
 *  Created on: 2024年11月1日
 *      Author: DaZhouGe668
 */

#include "PI.h"

void PI_MACRO ( PI_CONTROLLER *v )
{
	//误差
	v->up = v->Ref - v->Fbk ;

	//积分项
	v->ui = ( v->Out == v->v1 ) ? ( v->Ki*v->up + v->i1 ) : v->i1 ;
	v->i1 = v->ui ;

	//控制输出
	v->v1 = v->Kp * ( v->up + v->ui ) ;
	if ( v->v1 > v->Umax )
		v->Out = v->Umax ;
	else if ( v->v1 < v->Umin )
		v->Out = v->Umin ;
	else
		v->Out = v->v1 ;
}

//void P_MACRO ( P_CONTROLLER *v )
//{
//	v->Out = v->Kp*( v->Ref - v->Fbk ) ;
//	if ( v->Out > v->Umax )
//		v->Out = v->Umax ;
//	else if ( v->Out < v->Umin )
//		v->Out = v->Umin ;
//}
