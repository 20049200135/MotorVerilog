/*
 * PI.h
 *
 *  Created on: 2024年11月1日
 *      Author: DaZhouGe668
 */

#ifndef PI_H_
#define PI_H_

typedef struct {  float  Ref;   			// Input: reference set-point
				  float  Fbk;   			// Input: feedback
				  float  Out;   			// Output: controller output
				  float  Kp;				// Parameter: proportional loop gain
				  float  Ki;			    // Parameter: integral gain
				  float  Umax;			// Parameter: upper saturation limit
				  float  Umin;			// Parameter: lower saturation limit
				  float  up;				// Data: proportional term
				  float  ui;				// Data: integral term
				  float  v1;				// Data: pre-saturated controller output
				  float  i1;				// Data: integrator storage: ui(k-1)
				  float  w1;				// Data: saturation record: [u(k-1) - v(k-1)]
				} PI_CONTROLLER ;

typedef struct {
		float	Ref ;
		float	Fbk ;
		float	Out ;
		float	Kp ;
		float	Umax ;
		float	Umin ;
}P_CONTROLLER ;

//void P_MACRO ( P_CONTROLLER *v ) ;
void PI_MACRO ( PI_CONTROLLER *v ) ;

#endif /* PI_H_ */
