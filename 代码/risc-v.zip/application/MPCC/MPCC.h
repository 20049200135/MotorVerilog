/*
 * MPCC.h
 *
 *  Created on: 2024年11月1日
 *      Author: DaZhouGe668
 */

#ifndef MPCC_H_
#define MPCC_H_
#include "stdio.h"
#include "Parameter.h"
#include "math.h"

#define	PeriodMAX 	5000
typedef struct {
			//参考值
			float	Id_ref ;
			float	Iq_ref ;
			//测量值
			float	Udc ;
			float	Id ;
			float	Iq ;
			float	wre ;
			float	ThetaE ;
			//记录当前时刻的施加电压
			float	Vd_D1 ;
			float	Vq_D1 ;
			//切换时间
			float	duty ;
			//计数值
			uint32_t Sa_CCP ;
			uint32_t Sb_CCP ;
			uint32_t Sc_CCP ;
}MPCC_struct ;

#define MPCC_DEFAULTS {   0, \
                          0, \
                          0, \
                          0, \
                          0, \
						  0, \
                          0, \
						  0, \
						  0, \
						  0, \
						  1, \
						  1, \
						  1, \
              			  }

void Fuc_DoubleMPCC( MPCC_struct *v ) ;

#endif /* MPCC_H_ */
