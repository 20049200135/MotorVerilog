/*
 * MPCC.c
 *
 *  Created on: 2024年11月1日
 *      Author: DaZhouGe668
 */

#include "MPCC.h"

void Fuc_DoubleMPCC( MPCC_struct *v )
{
	const float inv_Ls = 1.0f /Ls ;

	const float	para1 = ( 1.0f - Ts*Rs*inv_Ls ) ;
	const float	para2 = Ts*inv_Ls ;
	const float	para3 = Ts*Phif*inv_Ls ;

	const float	cos_values[3] = { cos(v->ThetaE) , cos(v->ThetaE - 2.094395) , cos(v->ThetaE +  2.094395) } ;
	const float	sin_values[3] = { sin(v->ThetaE) , sin(v->ThetaE -  2.094395) , sin(v->ThetaE +  2.094395)  } ;

	//开关量和电压量计算
	const float	Udc_3 = v->Udc*0.3333333f ;
	const float	Udc2_3 = Udc_3*2.0f ;
	const float	Vabc[7][3] = {
													{  Udc2_3 , -Udc_3   ,  -Udc_3 	  } ,
													{ -Udc_3   ,  Udc2_3 ,  -Udc_3 	  } ,
													{  Udc_3   ,  Udc_3   ,   -Udc2_3 } ,
													{ -Udc_3   , -Udc_3   ,    Udc2_3 } ,
													{  Udc_3   , -Udc2_3 ,    Udc_3    } ,
													{ -Udc2_3 ,  Udc_3   ,    Udc_3    } ,
													{      0.0f    ,     0.0f     ,        0.0f     }				} ;
	const int		Sw[7][3] = { 	{ 1 , 0 , 0 } , { 0 , 1 , 0 } , { 1 , 1 , 0 } ,
												{ 0 , 0 , 1 } , { 1 , 0 , 1 } , { 0 , 1 , 1 } , { 0 , 0 , 0 }		} ;

	float	S_Vd1[7] , S_Vq1[7] , error1[7] , S_Vd2[7] , S_Vq2[7] , error2[7] , Sj , S_duty[7] , Vd_opt[7] , Vq_opt[7 ];
	float	Va , Vb , Vc ;
	//进行控制器一拍延时计算
	float	Id_1 = para1*v->Id + Ts*v->wre*v->Iq + para2*v->Vd_D1 ;
	float	Iq_1 = para1*v->Iq - Ts*v->wre*v->Id + para2*v->Vq_D1 - para3*v->wre ;

	//计算第一电压矢量作用时电流值的常量部分
	float	para_Id2 = para1*Id_1 + Ts*v->wre*Iq_1 ;
	float	para_Iq2 = para1*Iq_1 - Ts*v->wre*Id_1 - para3*v->wre ;
	for ( int i = 0 ; i<7 ; i++ )
	{
		Va = Vabc[i][0] ; Vb = Vabc[i][1] ; Vc = Vabc[i][2] ;
		S_Vd1[i] = 0.6666667f * ( Va*cos_values[0] + Vb*cos_values[1] + Vc*cos_values[2] ) ;
		S_Vq1[i] = -0.6666667f * ( Va*sin_values[0] + Vb*sin_values[1] + Vc*sin_values[2] ) ;

		float	Id_21 = para_Id2 + para2*S_Vd1[i] ;
		float	Iq_21 = para_Iq2 + para2*S_Vq1[i] ;

		error1[i] = fabs( v->Id_ref - Id_21 ) + fabs( v->Iq_ref - Iq_21 ) ;
	}

	//选择出使电流误差最小的第一电压参考矢量并记录
	int		min_row1 = 0 ;
	float	min_error1 = error1[0] ;
	for ( int j = 1 ; j<7 ; j++ )
	{
		if( error1[j] < min_error1 )
		{
			min_row1 = j ;
			min_error1 = error1[j] ;
		}
	}
	float	Vd_opt1 = S_Vd1[min_row1] , Vq_opt1 = S_Vq1[min_row1] ;
	int		Sa1 = Sw[min_row1][0] , Sb1 = Sw[min_row1][1] , Sc1 = Sw[min_row1][2] ;

	//计算第二矢量
	float	S0 = ( -Rs*Iq_1 - v->wre*Ls*Id_1 - v->wre*Phif )* inv_Ls ;
	float	Sopt1 = S0 + Vq_opt1* inv_Ls ;

	for ( int i = 0 ; i<7 ; i++ )
	{
		if ( i == min_row1 )
		{
			continue ;
		}
		else
		{
			Va = Vabc[i][0] ; Vb = Vabc[i][1] ; Vc = Vabc[i][2] ;
			S_Vd2[i] = 0.6666667f * ( Va*cos_values[0] + Vb*cos_values[1] + Vc*cos_values[2] ) ;
			S_Vq2[i] = -0.6666667f * ( Va*sin_values[0] + Vb*sin_values[1] + Vc*sin_values[2] ) ;
			Sj = S0 + S_Vq2[i]*inv_Ls ;

			//q轴电流无差拍( Iq_2 = Iq_ref )
			float	topt = ( v->Iq_ref - Iq_1 - Sj*Ts ) / ( Sopt1 - Sj ) ;
			if ( topt > Ts )
				topt = Ts ;
			else if ( topt < 0 )	//配置为最小值是101
				topt = 0 ;

			S_duty[i] = topt /Ts ;
			Vd_opt[i] = S_duty[i]*Vd_opt1 + ( 1.0f - S_duty[i])*S_Vd2[i] ;
			Vq_opt[i] = S_duty[i]*Vq_opt1 + ( 1.0f - S_duty[i])*S_Vq2[i] ;
			float	Id_22 = para_Id2 + para2*Vd_opt[i] ;
			float	Iq_22 = para_Iq2 + para2*Vq_opt[i] ;

			error2[i] = fabs( v->Id_ref - Id_22 ) + fabs( v->Iq_ref - Iq_22 ) ;
		}
	}

	int		min_row2 = 0 ;
	float	min_error2 = 100000.0 ;

	for ( int j = 0 ; j<7 ; j++ )
	{
		if ( j == min_row1 )
		{
			continue ;
		}
		else
		{
			if ( error2[j] < min_error2 )
			{
				min_row2 = j ;
				min_error2 = error2[j] ;
			}
		}
	}

	//记录这次的电压合成矢量
	v->Vd_D1 = Vd_opt[min_row2] ;
	v->Vq_D1 = Vq_opt[min_row2] ;
	int	Sa2 = Sw[min_row2][0] , Sb2 = Sw[min_row2][1] , Sc2 = Sw[min_row2][2] ;
	v->duty = S_duty[min_row2] ;

	//根据获得的开关状态输出PWM波占空比
	if ( Sa1 == Sa2 )
	{
		if ( Sa1 == 1 && Sa2 == 1 )
			v->Sa_CCP = 0 ;
		else
			v->Sa_CCP = PeriodMAX ;
	}
	else
	{
		if ( Sa1 == 1 && Sa2 == 0 )
			v->Sa_CCP = (1.0 - v->duty)*PeriodMAX ;
		else
			v->Sa_CCP = v->duty*PeriodMAX ;
	}

	//B相PWM波形
	if ( Sb1 == Sb2 )
	{
		if ( Sb1 == 1 && Sb2 == 1 )
			v->Sb_CCP = 0 ;
		else
			v->Sb_CCP = PeriodMAX ;
	}
	else
	{
		if ( Sb1 == 1 && Sb2 == 0 )
			v->Sb_CCP = (1.0 - v->duty)*PeriodMAX ;
		else
			v->Sb_CCP = v->duty*PeriodMAX ;
	}

	//B相PWM波形
	if ( Sc1 == Sc2 )
	{
		if ( Sc1 == 1 && Sc2 == 1 )
			v->Sc_CCP = 0 ;
		else
			v->Sc_CCP = PeriodMAX ;
	}
	else
	{
		if ( Sc1 == 1 && Sc2 == 0 )
			v->Sc_CCP = (1.0 - v->duty)*PeriodMAX ;
		else
			v->Sc_CCP = v->duty*PeriodMAX ;
	}

}
