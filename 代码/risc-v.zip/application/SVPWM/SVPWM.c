/*
 * SVPWM.c
 *
 *  Created on: 2024年11月5日
 *      Author: DaZhouGe668
 */

#include "SVPWM.h"

float 		duty_min = 105.0 /Period_Max ;

//Udc = 311
void SVPWM_MACRO( SVPWM_struct *v )
{
	float T1 , T2 , T3 ;
	v->VecSector = 0 ;
	float	Vref1 = v->Ubeta ;
	float	Vref2 = ( 0.86602f * v->Ualfa - 0.5f*v->Ubeta ) ;
	float	Vref3 = -( 0.86602f* v->Ualfa + 0.5f*v->Ubeta ) ;

	v->VecSector = (Vref1 > 0)? 1 : v->VecSector ;
	v->VecSector = (Vref2 > 0)? (v->VecSector+2) : v->VecSector ;
	v->VecSector = (Vref3 > 0)? (v->VecSector+4) : v->VecSector ;

	float	X = v->Ubeta*0.00556913f ;
	float	Y = ( 0.00482315f*v->Ualfa + 0.00278457f*v->Ubeta )  ;
	float	Z = ( - 0.00482315f*v->Ualfa + 0.00278457f*v->Ubeta )  ;

	switch( v->VecSector )
	{
		case 1 :
			T1 = Z ; T2 = Y ; break ;
		case 2 :
			T1 = Y ;  T2 = -X ; break ;
		case 3 :
			T1 = -Z ; T2 = X ; break ;
		case 4 :
			T1 = -X ; T2 = Z ; break ;
		case 5 :
			T1 = X ;  T2 = -Y ; break ;
		case 6 :
			T1 = -Y ; T2 = -Z ; break ;
		default : 	 break ;
	}

	if ( (T1+T2) > 1 )
	{
		T1 = T1 / (T1+T2) ;
		T2 = T2 / (T1+T2) ;
	}
	float	ta = ( 1 - (T1+T2) )*0.25f ;
	float	tb = ta + T1*0.5f ;
	float	tc = tb + T2*0.5f ;

	float	duty1 , duty2 , duty3 ;
	switch ( v->VecSector )
	{
		case 1 :
			duty1 = tb ; duty2 = ta ; duty3 = tc ; break ;
		case 2 :
			duty1 = ta ; duty2 = tc ; duty3 = tb ; break ;
		case 3 :
			duty1 = ta ; duty2 = tb ; duty3 = tc ; break ;
		case 4 :
			duty1 = tc ; duty2 = tb ; duty3 = ta ; break ;
		case 5 :
			duty1 = tc ; duty2 = ta ; duty3 = tb ; break ;
		case 6 :
			duty1 = tb ; duty2 = tc ; duty3 = ta ; break ;
		default : break ;
	}

	if (duty1 > 0.5 )
		duty1 = 0.5 ;
	else if ( duty1 <= duty_min )
		duty1 = duty_min ;

	if (duty2 > 0.5 )
		duty2 = 0.5 ;
	else if ( duty2 <= duty_min )
		duty2 = duty_min ;

	if (duty3 > 0.5 )
		duty3 = 0.5 ;
	else if ( duty3 <= duty_min )
		duty3 = duty_min ;

	v->Sa_CCP = (int) (duty1*Period_Max) ;
	v->Sb_CCP = (int) (duty2*Period_Max) ;
	v->Sc_CCP = (int) (duty3*Period_Max) ;
}
