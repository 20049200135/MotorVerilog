/*
 * SVPWM.H
 *
 *  Created on: 2024年11月5日
 *      Author: DaZhouGe668
 */

#ifndef SVPWM_H_
#define SVPWM_H_

#include "nuclei.h"
#define		Period_Max			12500

typedef struct {
		float			Ualfa ;
		float			Ubeta ;
		float			Udc ;
		uint16_t		VecSector ;

		uint32_t		Sa_CCP ;
		uint32_t		Sb_CCP ;
		uint32_t		Sc_CCP ;
}SVPWM_struct ;

void SVPWM_MACRO( SVPWM_struct *v ) ;

#endif /* SVPWM_H_ */
